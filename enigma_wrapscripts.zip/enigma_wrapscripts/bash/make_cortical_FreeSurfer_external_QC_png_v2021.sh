#!/bin/bash
#$ -S /bin/bash

printf "\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"
printf "Running External FreeSurfer through qsub \n"
printf "written by Iyad Ba Gari (IGC USC) - Apr 2021\n"
printf "+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"

export fs_dir=${enigmadir}/outputs/

for subject in $(ls ${fs_dir}|grep subj*);
do
# Define where matlab is located on your server
matlab  -nodisplay -batch "FS_external_QC('${fs_dir}', '${external_dir}', '${subject}')"
done
