#!/bin/bash
export FREESURFER_HOME=/Applications/freesurfer/7.1.0
source ${FREESURFER_HOME}/SetUpFreeSurfer.sh
export PATH=${PATH}:${FREESURFER_HOME}/bin

recon-all $@

exit $?
